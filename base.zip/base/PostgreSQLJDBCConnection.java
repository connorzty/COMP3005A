import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;

public class PostgreSQLJDBCConnection {

    private static final String url = "jdbc:postgresql://localhost:5432/students";
    private static final String user = "postgres";
    private static final String password = "ll001108";

    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
    public static void createStudentsTable() throws SQLException {//create the table with as per the schema provided
        Connection conn = connect();
        Statement stmt = conn.createStatement();
        String SQL = "CREATE TABLE IF NOT EXISTS students (" +
                     "student_id SERIAL PRIMARY KEY," +
                     "first_name VARCHAR(50) NOT NULL," +
                     "last_name VARCHAR(50) NOT NULL," +
                     "email VARCHAR(50) NOT NULL UNIQUE," +
                     "enrollment_date DATE);";
        stmt.execute(SQL);
        System.out.println("Student table are created");
        
    }
    public static void insertInitialData() throws SQLException {//insert the data in to the empty table 
        Connection conn = connect();
         Statement stmt = conn.createStatement();
        String SQL = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES " +
                     "('John', 'Doe', 'john.doe@example.com', '2023-09-01'), " +
                     "('Jane', 'Smith', 'jane.smith@example.com', '2023-09-01'), " +
                     "('Jim', 'Beam', 'jim.beam@example.com', '2023-09-02');";
        
        stmt.executeUpdate(SQL);
        System.out.println("Data are inserted");
        
    }
    public static void getAllStudents() throws SQLException{//print all the info in the student table
        String SQL = "SELECT * FROM students";
        Connection conn = connect();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);
        while (rs.next()) {
            System.out.println(rs.getInt("student_id") + " " +
                               rs.getString("first_name") + " " +
                               rs.getString("last_name") + " " +
                               rs.getString("email") + " " +
                               rs.getDate("enrollment_date"));
        }
    }
    public static void addStudent(String firstName, String lastName, String email, java.sql.Date enrollmentDate) throws SQLException {// add student with specific information
        Connection conn = connect();
        String SQL = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES (?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(SQL);
        pstmt.setString(1, firstName);
        pstmt.setString(2, lastName);
        pstmt.setString(3, email);
        pstmt.setDate(4, enrollmentDate);
        int affectedRows = pstmt.executeUpdate();
        if (affectedRows > 0) {
            System.out.println("The student has been add in to the database");
        } else {
            System.out.println("The student has not been add in to the database");
        }
    }
    public static void updateStudentEmail(int studentId, String newEmail) throws SQLException {//change email of specific student 
        Connection conn = connect();
        String SQL = "UPDATE students SET email = ? WHERE student_id = ?;";
        PreparedStatement pstmt = conn.prepareStatement(SQL);
        pstmt.setString(1, newEmail);
        pstmt.setInt(2, studentId);            
        int affectedRows = pstmt.executeUpdate();
        if (affectedRows > 0) {
            System.out.println("Email updated successfully for student ID: " + studentId);
        } else {
            System.out.println("Student not found with ID: " + studentId);
        }
        }
    public static void deleteStudent(int studentId) throws SQLException{//delete student info by specific student id
        Connection conn = connect();
        String SQL = "DELETE FROM students WHERE student_id = ?;";
        PreparedStatement pstmt = conn.prepareStatement(SQL);
        pstmt.setInt(1, studentId);
        int affectedRows = pstmt.executeUpdate();
        if (affectedRows > 0) {
            System.out.println("Student record is deleted with ID: " + studentId);
        } else {
            System.out.println("Student record is not found with ID: " + studentId);
        }
            
    }
        public static void main(String[] args) throws SQLException, ParseException{
        Connection conn = connect();
        Scanner scanner = new Scanner(System.in);
        if (conn != null) {
            System.out.println("Connected to PostgreSQL successfully!");
            createStudentsTable();
            insertInitialData();
            while(true){//main menu
                System.out.println("Please choose number:");
                System.out.println("1.Get all student");
                System.out.println("2.Add Student");
                System.out.println("3.Update student email");
                System.out.println("4.Delete student");
                System.out.println("5.quit");
                System.out.println("============================");
                String choosestr = scanner.nextLine();
                int choose = Integer.parseInt(choosestr);
                if(choose == 1){//out put all the record
                    System.out.println("User choose to print out all the student record");
                    getAllStudents();
                    System.out.println("============================");
                }else if(choose == 2){//inster the student info
                    System.out.println("User try to inserts a new student record into the students table");
                    System.out.println("Enter a firstname:");
                    String fname = scanner.nextLine();
                    System.out.println("Enter a lastname:");
                    String lname = scanner.nextLine();
                    System.out.println("Enter a email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter a enrollment_date(yyyy-mm-dd):");
                    String date = scanner.nextLine();//get string date
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    Date parsedDate = format.parse(date);//change string date to javadate
                    java.sql.Date sqlDate = new java.sql.Date(parsedDate.getTime());//change javadate to sql date
                    addStudent(fname, lname, email, sqlDate);
                    System.out.println("Print out all the student record again");
                    getAllStudents();
                    System.out.println("============================");
                }else if(choose == 3){//change student's email
                    System.out.println("Print out all the student record again");
                    getAllStudents();
                    System.out.println("Type in the the studnet number that exist above");
                    String snumber = scanner.nextLine();
                    int intsnumber = Integer.parseInt(snumber);
                    System.out.println("Type in the the email that exist above");
                    String getemail = scanner.nextLine();
                    updateStudentEmail( intsnumber,  getemail);
                    System.out.println("Print out all the student record again after change");
                    getAllStudents();
                    System.out.println("============================");

                }else if(choose == 4){//delete specific students record
                    System.out.println("Print out all the student record again");
                    getAllStudents();
                    System.out.println("Type in the the studnet number that exist above");
                    String snumber = scanner.nextLine();
                    int intsnumber = Integer.parseInt(snumber);
                    deleteStudent(intsnumber);
                    System.out.println("Print out all the student record again after change");
                    getAllStudents();
                    System.out.println("============================");
                }else if(choose == 5){
                    break;
                }else{
                    System.out.println("choose again");
                }
                
                
            }
            scanner.close();
            conn.close();
        } else {
            System.out.println("Failed to establish connection.");
        }
        
    }
}

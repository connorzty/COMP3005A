The program will set up the tables automatically when you run the program
The run the program:
    1.Compile the program:"javac -cp .:/Users/connor/Desktop/base/postgresql-42.6.0.jar PostgreSQLJDBCConnection.java"
    2.Run the program:"java -cp .:/Users/connor/Desktop/base/postgresql-42.6.0.jar PostgreSQLJDBCConnection.java"
How to use the program:After running the program, choose the number from 1 to 5 to use different function

https://www.youtube.com/watch?v=ZgdZ5XgZ_6k